#! /usr/bin/env bash

java -XX:MinHeapFreeRatio=20 -XX:MaxHeapFreeRatio=40 -Xms40m -jar ./bin/SRT.jar